Sprite assets used in this demo are from Kenney's Shooting Gallery pack: https://www.kenney.nl/assets/shooting-gallery and are under the CC0 1.0 Universal license.

You are free to use the source code in the demo (ONLY) as you want.